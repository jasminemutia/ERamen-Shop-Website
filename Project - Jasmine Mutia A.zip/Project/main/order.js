const button = document.getElementById("submitbutton");
button.addEventListener("click", function() { 

   const username = document.getElementById("uname").value;
   if(username.length < 5){
      alert('Name must be at least 5 characters long!');
      return; 
   }

   const email = document.getElementById("email").value;
   if(!email.endsWith('@gmail.com')) {
      alert("Email must end with @gmail.com");
      return;
   }

   const phone = document.getElementById("phone").value;
   let number = false, noLetter = false;
   for(let i = 0; i < phone.length; i++) {
      if(phone[i] >= '0' && phone[i] <= '9') {
         number = true;
      } else if(!phone[i] >= 'A' && !phone[i] <= 'Z' || !phone[i] >= 'a' && !phone[i] <= 'z') {
         noLetter = true;
      } else if(phone.length <= 7){
         alert('Phone number must be valid!');
         return; 
      }
      if(number && noLetter) break;
   }
   if(!number && !noLetter) {
      alert("Phone number must contains number!");
      return;
   }

   const preferences = document.getElementById("preferences").value;
   if (preferences == "") {
      alert("Please select your preferences!");
      return;
   }

   const address = document.getElementById("address").value;
   let  letter = false;
   for(let i = 0; i < address.length; i++) {
      if(address[i] >= 'a' && address[i] <= 'z' || address[i] >= 'A' && address[i] <= 'Z') {
         letter = true;
      }
      if(letter) break;
   }
   if(!letter) {
      alert("Please fill a valid address!");
      return;
   }

   alert("Submitted! Your orders will arrive soon.");
});


